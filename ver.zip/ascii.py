import pyfiglet
import time

def generate_wordart(text, font='standard'):
    try:
        # Cria uma instância do Figlet com a fonte especificada
        custom_fig = pyfiglet.Figlet(font=font)
        ascii_art = custom_fig.renderText(text)
        return ascii_art
    except pyfiglet.FigletError as e:
        return f"Erro ao gerar WordArt: {e}"

def main():
    print("Bem-vindo ao Gerador de WordArt!")
    text = input("Digite o texto para gerar a WordArt: ").strip()
    font = input("Digite o nome da fonte (deixe em branco para padrão): ").strip() or 'standard'

    ascii_art = generate_wordart(text, font)
    print("\nAqui está a sua WordArt:")
    print(ascii_art)

    # Aguarda 3 segundos antes de encerrar o programa
    time.sleep(10)

if __name__ == "__main__":
    main()
