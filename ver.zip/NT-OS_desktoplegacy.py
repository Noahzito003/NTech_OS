import tkinter as tk
from tkinter import scrolledtext, filedialog, colorchooser, messagebox
import time
import threading
import random
import webbrowser
import datetime

class NTechOS:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("NTechOS")
        self.root.geometry("800x600")
        self.root.configure(bg='lightgray')

        # Tela de carregamento
        self.show_loading_screen()

        # Interface principal
        self.create_main_interface()

    def show_loading_screen(self):
        self.loading_screen = tk.Toplevel(self.root)
        self.loading_screen.title("Carregando")
        self.loading_screen.geometry("400x100")
        self.loading_screen.configure(bg='lightgray')

        label = tk.Label(self.loading_screen, text="Carregando NTechOS...", font=("Arial", 14), bg='lightgray')
        label.pack(pady=10)

        self.progress = tk.DoubleVar()
        progress_bar = tk.Progressbar(self.loading_screen, variable=self.progress, maximum=100, length=300)
        progress_bar.pack(pady=10)

        self.update_progress()

    def update_progress(self):
        for i in range(101):
            time.sleep(0.05)
            self.progress.set(i)
            self.root.update_idletasks()
        self.loading_screen.destroy()

    def create_main_interface(self):
        self.taskbar = tk.Frame(self.root, bg='darkgray', height=30)
        self.taskbar.pack(side=tk.BOTTOM, fill=tk.X)

        # Adicionar botões na barra de tarefas
        self.create_taskbar_button("Texto", self.open_text_editor)
        self.create_taskbar_button("Navegador", self.open_browser)
        self.create_taskbar_button("Relógio", self.open_clock)
        self.create_taskbar_button("Pong", self.play_pong)
        self.create_taskbar_button("Space Invaders", self.play_space_invaders)

    def create_taskbar_button(self, text, command):
        button = tk.Button(self.taskbar, text=text, command=command)
        button.pack(side=tk.LEFT, padx=5, pady=5)

    def open_text_editor(self):
        editor = tk.Toplevel(self.root)
        editor.title("NTech Text Editor")

        self.text_area = scrolledtext.ScrolledText(editor, wrap=tk.WORD, width=80, height=20)
        self.text_area.pack(expand=True, fill='both', padx=10, pady=10)

        button_frame = tk.Frame(editor)
        button_frame.pack(pady=5)

        save_button = tk.Button(button_frame, text="Salvar", command=self.save_file)
        save_button.pack(side=tk.LEFT, padx=5)

        color_button = tk.Button(button_frame, text="Cor do Texto", command=self.change_color)
        color_button.pack(side=tk.LEFT, padx=5)

    def save_file(self):
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if file_path:
                with open(file_path, 'w') as file:
                    file.write(self.text_area.get(1.0, tk.END))
                messagebox.showinfo("Salvar Arquivo", "Arquivo salvo com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar o arquivo: {e}")

    def change_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.text_area.config(fg=color)

    def open_browser(self):
        webbrowser.open("https://www.example.com")  # Substitua pelo URL desejado

    def open_clock(self):
        clock_window = tk.Toplevel(self.root)
        clock_window.title("Relógio")

        time_label = tk.Label(clock_window, font=("Arial", 48))
        time_label.pack(pady=20)

        date_label = tk.Label(clock_window, font=("Arial", 24))
        date_label.pack(pady=10)

        def update_time():
            now = datetime.datetime.now()
            time_str = now.strftime("%H:%M:%S")
            date_str = now.strftime("%d/%m/%Y")
            time_label.config(text=time_str)
            date_label.config(text=date_str)
            clock_window.after(1000, update_time)

        update_time()

    def play_pong(self):
        import turtle
        import tkinter as tk

        def pong_game():
            wn = turtle.Screen()
            wn.title("Pong")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            paddle_a = turtle.Turtle()
            paddle_a.speed(0)
            paddle_a.shape("square")
            paddle_a.color("white")
            paddle_a.shapesize(stretch_wid=6, stretch_len=1)
            paddle_a.penup()
            paddle_a.goto(-350, 0)

            paddle_b = turtle.Turtle()
            paddle_b.speed(0)
            paddle_b.shape("square")
            paddle_b.color("white")
            paddle_b.shapesize(stretch_wid=6, stretch_len=1)
            paddle_b.penup()
            paddle_b.goto(350, 0)

            ball = turtle.Turtle()
            ball.speed(1)
            ball.shape("square")
            ball.color("white")
            ball.penup()
            ball.goto(0, 0)
            ball.dx = 0.175
            ball.dy = -0.175

            def paddle_a_up():
                y = paddle_a.ycor()
                if y < 250:
                    y += 20
                    paddle_a.sety(y)

            def paddle_a_down():
                y = paddle_a.ycor()
                if y > -240:
                    y -= 20
                    paddle_a.sety(y)

            def paddle_b_up():
                y = paddle_b.ycor()
                if y < 250:
                    y += 20
                    paddle_b.sety(y)

            def paddle_b_down():
                y = paddle_b.ycor()
                if y > -240:
                    y -= 20
                    paddle_b.sety(y)

            wn.listen()
            wn.onkeypress(paddle_a_up, "w")
            wn.onkeypress(paddle_a_down, "s")
            wn.onkeypress(paddle_b_up, "Up")
            wn.onkeypress(paddle_b_down, "Down")

            while True:
                wn.update()

                ball.setx(ball.xcor() + ball.dx)
                ball.sety(ball.ycor() + ball.dy)

                if ball.ycor() > 290:
                    ball.sety(290)
                    ball.dy *= -1

                if ball.ycor() < -290:
                    ball.sety(-290)
                    ball.dy *= -1

                if ball.xcor() > 390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if ball.xcor() < -390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if (ball.dx > 0) and (350 > ball.xcor() > 340) and (paddle_b.ycor() + 50 > ball.ycor() > paddle_b.ycor() - 50):
                    ball.setx(340)
                    ball.dx *= -1

                if (ball.dx < 0) and (-350 < ball.xcor() < -340) and (paddle_a.ycor() + 50 > ball.ycor() > paddle_a.ycor() - 50):
                    ball.setx(-340)
                    ball.dx *= -1

        # Iniciar o jogo Pong em uma nova janela
        threading.Thread(target=pong_game).start()

    def play_space_invaders(self):
        import turtle
        import random

        def space_invaders_game():
            wn = turtle.Screen()
            wn.title("Space Invaders")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            player = turtle.Turtle()
            player.speed(0)
            player.shape("square")
            player.color("white")
            player.penup()
            player.goto(0, -250)
            player.shapesize(stretch_wid=1, stretch_len=5)

            bullet = turtle.Turtle()
            bullet.speed(0)
            bullet.shape("square")
            bullet.color("red")
            bullet.penup()
            bullet.hideturtle()
            bullet.speed(40)

            invaders = []
            for _ in range(5):
                invader = turtle.Turtle()
                invader.speed(0)
                invader.shape("square")
                invader.color("green")
                invader.penup()
                invader.goto(random.randint(-300, 300), random.randint(100, 250))
                invaders.append(invader)

            def move_left():
                x = player.xcor()
                if x > -350:
                    x -= 20
                    player.setx(x)

            def move_right():
                x = player.xcor()
                if x < 350:
                    x += 20
                    player.setx(x)

            def shoot():
                if not bullet.isvisible():
                    bullet.setx(player.xcor())
                    bullet.sety(player.ycor() + 10)
                    bullet.showturtle()

            wn.listen()
            wn.onkeypress(move_left, "Left")
            wn.onkeypress(move_right, "Right")
            wn.onkeypress(shoot, "space")

            while True:
                wn.update()

                if bullet.isvisible():
                    bullet.sety(bullet.ycor() + 20)

                    if bullet.ycor() > 290:
                        bullet.hideturtle()

                    for invader in invaders:
                        if invader.distance(bullet) < 20:
                            invader.hideturtle()
                            bullet.hideturtle()

        # Iniciar o jogo Space Invaders em uma nova janela
        threading.Thread(target=space_invaders_game).start()

if __name__ == "__main__":
    app = NTechOS()
    app.root.mainloop()
