import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, simpledialog, font
from tkinter import ttk
import subprocess
import platform
import webview
import os
import random
import turtle
from PIL import Image, ImageDraw, ImageFont
from music21 import stream, note, chord, metadata

class NTechOSConsole:
    def __init__(self):
        self.system = platform.system()
        self.password = 'changeme'
        self.create_loading_screen()
        self.main_menu()

    def create_loading_screen(self):
        """Cria e exibe a tela de carregamento com uma barra de progresso"""
        self.loading_root = tk.Tk()
        self.loading_root.title("Carregando NTechOS Console")
        self.loading_root.geometry("400x200")

        tk.Label(self.loading_root, text="Carregando NTechOS Console...", font=("Arial", 16)).pack(pady=20)

        self.progress = ttk.Progressbar(self.loading_root, length=300, mode='indeterminate')
        self.progress.pack(pady=20)
        self.progress.start()

        self.loading_root.after(3000, self.loading_root.destroy)

    def main_menu(self):
        """Cria o menu principal do console"""
        self.root = tk.Tk()
        self.root.title("NTechOS Console")

        menu_bar = tk.Menu(self.root)
        self.root.config(menu=menu_bar)

        app_menu = tk.Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Aplicativos", menu=app_menu)
        app_menu.add_command(label="Editor de Texto", command=self.open_text_editor)
        app_menu.add_command(label="Notador Musical", command=self.open_music_notation)
        app_menu.add_command(label="Explorador de Arquivos", command=self.open_file_explorer)
        app_menu.add_command(label="Calculadora", command=self.open_calculator)
        app_menu.add_command(label="Navegador", command=self.open_browser)
        app_menu.add_command(label="Pong", command=self.play_pong)
        app_menu.add_command(label="Space Invaders", command=self.play_space_invaders)
        app_menu.add_command(label="Minecraft Classic", command=self.open_minecraft_classic)
        app_menu.add_separator()
        app_menu.add_command(label="Sair", command=self.root.quit)

        self.root.mainloop()

    def open_text_editor(self):
        """Abre o NTech Text Editor"""
        editor_root = tk.Tk()
        editor_root.title("NTech Text Editor")

        self.font_var = tk.StringVar(value="Arial")
        self.size_var = tk.StringVar(value="12")

        font_menu = tk.OptionMenu(editor_root, self.font_var, *font.families(), command=self.change_font)
        font_menu.pack(side=tk.LEFT)

        size_menu = tk.OptionMenu(editor_root, self.size_var, *[str(size) for size in range(8, 73, 2)], command=self.change_font)
        size_menu.pack(side=tk.LEFT)

        self.text_area = scrolledtext.ScrolledText(editor_root, wrap=tk.WORD, width=80, height=20)
        self.text_area.pack(expand=True, fill='both')

        save_button = tk.Button(editor_root, text="Salvar", command=self.save_file)
        save_button.pack(side=tk.RIGHT)

        wordart_button = tk.Button(editor_root, text="Inserir WordArt", command=self.insert_wordart)
        wordart_button.pack(side=tk.LEFT)

        editor_root.mainloop()

    def change_font(self, event=None):
        """Muda a fonte do editor de texto"""
        font_name = self.font_var.get()
        font_size = self.size_var.get()
        self.text_area.config(font=(font_name, font_size))

    def insert_wordart(self):
        """Insere WordArt no editor de texto"""
        wordart_text = simpledialog.askstring("WordArt", "Digite o texto do WordArt:")
        if wordart_text:
            # Cria uma imagem para o WordArt
            image = Image.new('RGB', (300, 100), color='white')
            draw = ImageDraw.Draw(image)
            try:
                wordart_font = ImageFont.truetype("arial.ttf", 50)
            except IOError:
                wordart_font = ImageFont.load_default()
            draw.text((10, 25), wordart_text, font=wordart_font, fill='black')
            image.save('wordart.png')
            wordart_image = tk.PhotoImage(file='wordart.png')
            self.text_area.image_create(tk.END, image=wordart_image)

    def save_file(self):
        """Salva o arquivo do editor de texto"""
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if file_path:
                with open(file_path, 'w') as file:
                    file.write(self.text_area.get(1.0, tk.END))
                messagebox.showinfo("Salvar Arquivo", "Arquivo salvo com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar o arquivo: {e}")

    def open_music_notation(self):
        """Abre o Notador Musical"""
        notation_root = tk.Tk()
        notation_root.title("NTech Music Notation")

        canvas = tk.Canvas(notation_root, bg='white')
        canvas.pack(fill=tk.BOTH, expand=True)
        canvas.bind("<Button-1>", self.on_canvas_click)

        clear_button = tk.Button(notation_root, text="Limpar", command=self.clear_canvas)
        clear_button.pack(side=tk.LEFT)

        save_button = tk.Button(notation_root, text="Salvar Imagem", command=self.save_image)
        save_button.pack(side=tk.LEFT)

        self.canvas = canvas
        notation_root.mainloop()

    def draw_note(self, x, y, pitch='C4'):
        """Desenha uma nota musical no canvas"""
        r = 10
        self.canvas.create_oval(x-r, y-r, x+r, y+r, fill='black')
        self.canvas.create_line(x, y-r, x, y+r, fill='black')
        self.canvas.create_text(x, y + 15, text=pitch, fill='black')

    def on_canvas_click(self, event):
        """Desenha uma nota quando o canvas é clicado"""
        pitch = simpledialog.askstring("Nota", "Digite o nome da nota (e.g., C4, D#5):")
        if pitch:
            self.draw_note(event.x, event.y, pitch)

    def clear_canvas(self):
        """Limpa o canvas"""
        self.canvas.delete('all')

    def save_image(self):
        """Salva o conteúdo do canvas como imagem"""
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
            if file_path:
                self.canvas.postscript(file=file_path.replace('.png', '.eps'))
                img = Image.open(file_path.replace('.png', '.eps'))
                img.save(file_path)
                os.remove(file_path.replace('.png', '.eps'))
                messagebox.showinfo("Salvar Imagem", "Imagem salva com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar a imagem: {e}")

    def open_file_explorer(self):
        """Abre o Explorador de Arquivos"""
        explorer_root = tk.Tk()
        explorer_root.title("Explorador de Arquivos - NTechOS")

        tree = ttk.Treeview(explorer_root, columns=('Name', 'Size', 'Date Modified'), show='headings')
        tree.heading('Name', text='Nome')
        tree.heading('Size', text='Tamanho')
        tree.heading('Date Modified', text='Data de Modificação')

        tree.bind("<Double-1>", self.on_treeview_item_double_click)
        tree.pack(expand=True, fill='both')

        self.tree = tree
        self.update_treeview(os.getcwd())
        explorer_root.mainloop()

    def update_treeview(self, path):
        """Atualiza o TreeView do explorador de arquivos"""
        self.tree.delete(*self.tree.get_children())
        try:
            for entry in os.scandir(path):
                if entry.is_file():
                    size = os.path.getsize(entry.path)
                    modified = os.path.getmtime(entry.path)
                    self.tree.insert('', 'end', values=(entry.name, f"{size} bytes", modified))
                elif entry.is_dir():
                    self.tree.insert('', 'end', values=(entry.name, 'Diretório', ''))
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao acessar o diretório: {e}")

    def on_treeview_item_double_click(self, event):
        """Muda o diretório no explorador de arquivos"""
        item = self.tree.selection()[0]
        item_text = self.tree.item(item, 'values')[0]
        full_path = os.path.join(os.getcwd(), item_text)
        if os.path.isdir(full_path):
            os.chdir(full_path)
            self.update_treeview(full_path)

    def open_calculator(self):
        """Abre a Calculadora"""
        try:
            if self.system == "Windows":
                subprocess.run(["calc"])
            else:
                subprocess.run(["gnome-calculator"])
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao abrir a calculadora: {e}")

    def open_browser(self):
        """Abre o navegador padrão"""
        webview.create_window("NTechOS Browser", "https://www.google.com")
        webview.start()

    def play_pong(self):
        """Joga Pong"""
        # Pong com Turtle
        def pong():
            wn = turtle.Screen()
            wn.title("Pong")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            # Paddle A
            paddle_a = turtle.Turtle()
            paddle_a.speed(0)
            paddle_a.shape("square")
            paddle_a.color("white")
            paddle_a.shapesize(stretch_wid=6, stretch_len=1)
            paddle_a.penup()
            paddle_a.goto(-350, 0)

            # Paddle B
            paddle_b = turtle.Turtle()
            paddle_b.speed(0)
            paddle_b.shape("square")
            paddle_b.color("white")
            paddle_b.shapesize(stretch_wid=6, stretch_len=1)
            paddle_b.penup()
            paddle_b.goto(350, 0)

            # Ball
            ball = turtle.Turtle()
            ball.speed(40)
            ball.shape("square")
            ball.color("white")
            ball.penup()
            ball.goto(0, 0)
            ball.dx = 0.175
            ball.dy = -0.175

            # Functions
            def paddle_a_up():
                y = paddle_a.ycor()
                if y < 250:
                    y += 20
                    paddle_a.sety(y)

            def paddle_a_down():
                y = paddle_a.ycor()
                if y > -240:
                    y -= 20
                    paddle_a.sety(y)

            def paddle_b_up():
                y = paddle_b.ycor()
                if y < 250:
                    y += 20
                    paddle_b.sety(y)

            def paddle_b_down():
                y = paddle_b.ycor()
                if y > -240:
                    y -= 20
                    paddle_b.sety(y)

            # Keyboard bindings
            wn.listen()
            wn.onkeypress(paddle_a_up, "w")
            wn.onkeypress(paddle_a_down, "s")
            wn.onkeypress(paddle_b_up, "Up")
            wn.onkeypress(paddle_b_down, "Down")

            # Main game loop
            while True:
                wn.update()

                ball.setx(ball.xcor() + ball.dx)
                ball.sety(ball.ycor() + ball.dy)

                # Border checking
                if ball.ycor() > 290:
                    ball.sety(290)
                    ball.dy *= -1

                if ball.ycor() < -290:
                    ball.sety(-290)
                    ball.dy *= -1

                if ball.xcor() > 390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if ball.xcor() < -390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                # Paddle and ball collisions
                if (ball.dx > 0) and (350 > ball.xcor() > 340) and (paddle_b.ycor() + 50 > ball.ycor() > paddle_b.ycor() - 50):
                    ball.setx(340)
                    ball.dx *= -1

                if (ball.dx < 0) and (-350 < ball.xcor() < -340) and (paddle_a.ycor() + 50 > ball.ycor() > paddle_a.ycor() - 50):
                    ball.setx(-340)
                    ball.dx *= -1

        pong()

    def play_space_invaders(self):
        """Joga Space Invaders"""
        # Space Invaders básico
        def space_invaders():
            wn = turtle.Screen()
            wn.title("Space Invaders")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            # Player
            player = turtle.Turtle()
            player.speed(0)
            player.shape("square")
            player.color("white")
            player.penup()
            player.goto(0, -250)
            player.shapesize(stretch_wid=1, stretch_len=5)

            # Bullet
            bullet = turtle.Turtle()
            bullet.speed(0)
            bullet.shape("square")
            bullet.color("red")
            bullet.penup()
            bullet.hideturtle()
            bullet.speed(40)

            # Invaders
            invaders = []
            for _ in range(5):
                invader = turtle.Turtle()
                invader.speed(0)
                invader.shape("square")
                invader.color("green")
                invader.penup()
                invader.goto(random.randint(-300, 300), random.randint(100, 250))
                invaders.append(invader)

            # Functions
            def move_left():
                x = player.xcor()
                if x > -350:
                    x -= 20
                    player.setx(x)

            def move_right():
                x = player.xcor()
                if x < 350:
                    x += 20
                    player.setx(x)

            def shoot():
                if not bullet.isvisible():
                    bullet.setx(player.xcor())
                    bullet.sety(player.ycor() + 10)
                    bullet.showturtle()

            # Keyboard bindings
            wn.listen()
            wn.onkeypress(move_left, "Left")
            wn.onkeypress(move_right, "Right")
            wn.onkeypress(shoot, "space")

            # Main game loop
            while True:
                wn.update()

                # Move bullet
                if bullet.isvisible():
                    bullet.sety(bullet.ycor() + 20)
                    if bullet.ycor() > 290:
                        bullet.hideturtle()

                # Check for collision with invaders
                for invader in invaders:
                    if bullet.distance(invader) < 20:
                        invader.goto(random.randint(-300, 300), random.randint(100, 250))
                        bullet.hideturtle()

        space_invaders()

    def open_minecraft_classic(self):
        """Abre o Minecraft Classic no navegador"""
        webview.create_window("Minecraft Classic", "https://classic.minecraft.net/")
        webview.start()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    NTechOSConsole().run()
