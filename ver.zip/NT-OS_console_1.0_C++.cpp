#include <iostream>
#include <string>
#include <cstdlib>
#include <QApplication>
#include <QMessageBox>
#include <QInputDialog>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QPlainTextEdit>
#include <QProcess>

class NTechConsole : public QWidget {
    Q_OBJECT

public:
    NTechConsole(QWidget *parent = nullptr);

private slots:
    void openBrowser();
    void executeCommand();
    void changePassword();

private:
    QPlainTextEdit *outputArea;
    std::string password;
    void verifyPassword();
};

NTechConsole::NTechConsole(QWidget *parent) : QWidget(parent), password("changeme") {
    QVBoxLayout *layout = new QVBoxLayout;

    QPushButton *browserButton = new QPushButton("Open Browser");
    QPushButton *commandButton = new QPushButton("Execute Command");
    QPushButton *passwordButton = new QPushButton("Change Password");

    outputArea = new QPlainTextEdit;
    outputArea->setReadOnly(true);

    layout->addWidget(browserButton);
    layout->addWidget(commandButton);
    layout->addWidget(passwordButton);
    layout->addWidget(outputArea);

    connect(browserButton, &QPushButton::clicked, this, &NTechConsole::openBrowser);
    connect(commandButton, &QPushButton::clicked, this, &NTechConsole::executeCommand);
    connect(passwordButton, &QPushButton::clicked, this, &NTechConsole::changePassword);

    setLayout(layout);
    verifyPassword();
}

void NTechConsole::verifyPassword() {
    bool ok;
    QString enteredPassword = QInputDialog::getText(this, tr("Password"), tr("Enter password:"), QLineEdit::Password, "", &ok);
    if (!ok || enteredPassword.toStdString() != password) {
        QMessageBox::critical(this, tr("Error"), tr("Incorrect password. Closing the console."));
        exit(EXIT_FAILURE);
    }
}

void NTechConsole::openBrowser() {
    QString url = QInputDialog::getText(this, tr("Browser"), tr("Enter URL:"), QLineEdit::Normal, "http://");
    if (!url.isEmpty()) {
        QProcess::startDetached("xdg-open", QStringList() << url);
    }
}

void NTechConsole::executeCommand() {
    bool ok;
    QString command = QInputDialog::getText(this, tr("Execute Command"), tr("Enter command:"), QLineEdit::Normal, "", &ok);
    if (ok && !command.isEmpty()) {
        QProcess process;
        process.start(command);
        process.waitForFinished();
        QString output = process.readAllStandardOutput();
        outputArea->appendPlainText(output);
    }
}

void NTechConsole::changePassword() {
    bool ok;
    QString newPassword = QInputDialog::getText(this, tr("Change Password"), tr("Enter new password:"), QLineEdit::Password, "", &ok);
    if (ok) {
        password = newPassword.toStdString();
        QMessageBox::information(this, tr("Change Password"), tr("Password changed successfully!"));
    }
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    NTechConsole console;
    console.setWindowTitle("NTechOS Console");
    console.resize(600, 400);
    console.show();
    return app.exec();
}
