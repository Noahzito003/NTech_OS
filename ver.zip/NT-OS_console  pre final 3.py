import cmd
import subprocess
import platform
import webview
import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, ttk, simpledialog, font
import os
import sys
import turtle
import random

class NTechConsole(cmd.Cmd):
    intro = 'Bem-vindo ao NTechOS Console da NTech. Digite "help" ou "?" para listar os comandos.\n'
    prompt = '(NTechOS) '
    file = None

    def __init__(self):
        super().__init__()
        self.command_history = []
        self.password = "changeme"
        self.system = platform.system()

        # Verificação de senha
        self.verify_password()

    def verify_password(self):
        entered_password = simpledialog.askstring("Senha", "Digite a senha:", show='*')
        if entered_password != self.password:
            print("Senha incorreta. Fechando o console.")
            sys.exit()

    def precmd(self, line):
        self.command_history.append(line)
        return line

    def do_navegador(self, url=''):
        """Abre um navegador embutido."""
        if not url:
            url = simpledialog.askstring("Navegador", "Digite o URL:", initialvalue='http://')
            if not url.startswith('http'):
                url = 'http://' + url
        try:
            webview.create_window('Navegador NTech', url)
            webview.start()
        except Exception as e:
            print(f"Erro ao abrir o navegador: {e}")

    def do_explorador(self, arg):
        """Abre o explorador de arquivos."""
        self.open_file_explorer()

    def do_texteditor(self, arg):
        """Abre o NTech Text Editor."""
        self.open_text_editor()

    def do_calculadora(self, arg):
        """Abre a Calculadora."""
        self.open_calculator()

    def do_pong(self, arg):
        """Joga Pong."""
        self.play_pong()

    def do_space_invaders(self, arg):
        """Joga Space Invaders."""
        self.play_space_invaders()

    def do_minecraft(self, arg):
        """Joga Minecraft Classic."""
        self.open_minecraft_classic()

    def do_notacao(self, arg):
        """Abre o Notador Musical - NTechOS."""
        self.open_music_notation()

    def do_mudar_senha(self, arg):
        """Muda a senha do console."""
        self.change_password()

    def do_sair(self, arg):
        """Sai do NTechOS Console."""
        print('Saindo do NTechOS Console.')
        return True

    def do_exec(self, comando):
        """Executa comandos do sistema (Windows/Linux)."""
        try:
            if self.system == "Windows":
                result = subprocess.run(comando, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            else:
                result = subprocess.run(comando, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            print(result.stdout)
        except subprocess.CalledProcessError as e:
            print(f"Erro ao executar comando: {e.stderr}")

    def do_hist(self, arg):
        """Mostra o histórico de comandos."""
        for i, command in enumerate(self.command_history):
            print(f'{i + 1}: {command}')

    def do_clear(self, arg):
        """Limpa o console."""
        if self.system == "Windows":
            os.system('cls')
        else:
            os.system('clear')

    def complete(self, text, state):
        commands = [cmd[3:] for cmd in self.get_names() if cmd.startswith('do_' + text)]
        if state < len(commands):
            return commands[state]
        return None

    def open_file_explorer(self):
        """Abre o explorador de arquivos."""
        explorer = tk.Tk()
        explorer.title("Explorador de Arquivos - NTechOS")
        explorer.geometry("800x600")

        file_tree = ttk.Treeview(explorer, columns=('Name', 'Size', 'Date Modified'), show='headings')
        file_tree.heading('Name', text='Nome')
        file_tree.heading('Size', text='Tamanho')
        file_tree.heading('Date Modified', text='Data de Modificação')

        def update_treeview(path):
            file_tree.delete(*file_tree.get_children())
            try:
                for entry in os.scandir(path):
                    if entry.is_file():
                        size = os.path.getsize(entry.path)
                        modified = os.path.getmtime(entry.path)
                        file_tree.insert('', 'end', values=(entry.name, f"{size} bytes", modified))
                    elif entry.is_dir():
                        file_tree.insert('', 'end', values=(entry.name, 'Diretório', ''))

                file_tree.bind("<Double-1>", lambda e: self.on_treeview_item_double_click(file_tree, path))
                file_tree.pack(expand=True, fill='both')
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao acessar o diretório: {e}")

        def on_treeview_item_double_click(file_tree, path):
            item = file_tree.selection()[0]
            item_text = file_tree.item(item, 'values')[0]
            full_path = os.path.join(path, item_text)
            if os.path.isdir(full_path):
                update_treeview(full_path)

        update_treeview(os.getcwd())
        explorer.mainloop()

    def open_text_editor(self):
        """Abre o NTech Text Editor com seleção de fontes."""
        text_editor = tk.Tk()
        text_editor.title("NTech Text Editor")

        # Configuração do menu de fontes
        def change_font(event=None):
            font_name = font_var.get()
            font_size = size_var.get()
            text_area.config(font=(font_name, font_size))

        font_var = tk.StringVar(value="Arial")
        size_var = tk.StringVar(value="12")

        font_menu = tk.OptionMenu(text_editor, font_var, *font.families(), command=change_font)
        font_menu.pack(side=tk.LEFT)

        size_menu = tk.OptionMenu(text_editor, size_var, *[str(size) for size in range(8, 73, 2)], command=change_font)
        size_menu.pack(side=tk.LEFT)

        text_area = scrolledtext.ScrolledText(text_editor, wrap=tk.WORD, width=80, height=20)
        text_area.pack(expand=True, fill='both')

        def save_file():
            try:
                file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
                if file_path:
                    with open(file_path, 'w') as file:
                        file.write(text_area.get(1.0, tk.END))
                    messagebox.showinfo("Salvar Arquivo", "Arquivo salvo com sucesso!")
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao salvar o arquivo: {e}")

        save_button = tk.Button(text_editor, text="Salvar", command=save_file)
        save_button.pack(side=tk.RIGHT)

        text_editor.mainloop()

    def open_calculator(self):
        """Abre a Calculadora."""
        calc = tk.Tk()
        calc.title("Calculadora - NTechOS")

        def evaluate(event=None):
            try:
                result = str(eval(display.get()))
                display.delete(0, tk.END)
                display.insert(tk.END, result)
            except Exception as e:
                display.delete(0, tk.END)
                display.insert(tk.END, "Erro")

        display = tk.Entry(calc, font=("Arial", 20), bd=10, insertwidth=4, width=14, borderwidth=4)
        display.grid(row=0, column=0, columnspan=4)

        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+'
        ]

        row = 1
        col = 0
        for button in buttons:
            if button == '=':
                btn = tk.Button(calc, text=button, padx=20, pady=20, bd=8, fg='black', font=("Arial", 18),
                             command=evaluate)
                btn.grid(row=row, column=col, columnspan=2)
                col += 1
            else:
                btn = tk.Button(calc, text=button, padx=20, pady=20, bd=8, fg='black', font=("Arial", 18),
                             command=lambda b=button: display.insert(tk.END, b))
                btn.grid(row=row, column=col)
            col += 1
            if col > 3:
                col = 0
                row += 1

        calc.bind('<Return>', evaluate)
        calc.mainloop()

    def play_pong(self):
        """Joga Pong."""
        try:
            # Configuração da janela
            wn = turtle.Screen()
            wn.title("Pong - NTechOS")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            # Paddle A
            paddle_a = turtle.Turtle()
            paddle_a.speed(0)
            paddle_a.shape("square")
            paddle_a.color("white")
            paddle_a.shapesize(stretch_wid=6, stretch_len=1)
            paddle_a.penup()
            paddle_a.goto(-350, 0)

            # Paddle B
            paddle_b = turtle.Turtle()
            paddle_b.speed(0)
            paddle_b.shape("square")
            paddle_b.color("white")
            paddle_b.shapesize(stretch_wid=6, stretch_len=1)
            paddle_b.penup()
            paddle_b.goto(350, 0)

            # Bola
            ball = turtle.Turtle()
            ball.speed(40)
            ball.shape("square")
            ball.color("white")
            ball.penup()
            ball.goto(0, 0)
            ball.dx = 0.175
            ball.dy = -0.175

            # Funções
            def paddle_a_up():
                y = paddle_a.ycor()
                y += 20
                paddle_a.sety(y)

            def paddle_a_down():
                y = paddle_a.ycor()
                y -= 20
                paddle_a.sety(y)

            def paddle_b_up():
                y = paddle_b.ycor()
                y += 20
                paddle_b.sety(y)

            def paddle_b_down():
                y = paddle_b.ycor()
                y -= 20
                paddle_b.sety(y)

            # Controles do teclado
            wn.listen()
            wn.onkeypress(paddle_a_up, "w")
            wn.onkeypress(paddle_a_down, "s")
            wn.onkeypress(paddle_b_up, "Up")
            wn.onkeypress(paddle_b_down, "Down")

            # Loop principal do jogo
            while True:
                wn.update()

                # Movendo a bola
                ball.setx(ball.xcor() + ball.dx)
                ball.sety(ball.ycor() + ball.dy)

                # Colisão com a parede superior
                if ball.ycor() > 290:
                    ball.sety(290)
                    ball.dy *= -1

                # Colisão com a parede inferior
                if ball.ycor() < -290:
                    ball.sety(-290)
                    ball.dy *= -1

                # Colisão com a parede direita
                if ball.xcor() > 390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                # Colisão com a parede esquerda
                if ball.xcor() < -390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                # Colisão com os paddles
                if (340 < ball.xcor() < 350) and (paddle_b.ycor() - 50 < ball.ycor() < paddle_b.ycor() + 50):
                    ball.setx(340)
                    ball.dx *= -1

                elif (-350 < ball.xcor() < -340) and (paddle_a.ycor() - 50 < ball.ycor() < paddle_a.ycor() + 50):
                    ball.setx(-340)
                    ball.dx *= -1
        except turtle.TurtleGraphicsError as e:
            print(f"Erro ao jogar Pong: {e}")

    def play_space_invaders(self):
        """Joga Space Invaders."""
        try:
            # Configuração da janela
            wn = turtle.Screen()
            wn.title("Space Invaders - NTechOS")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            # Configurações da nave do jogador
            player = turtle.Turtle()
            player.color("blue")
            player.shape("triangle")
            player.penup()
            player.speed(0)
            player.setposition(0, -250)
            player.setheading(90)
            player_speed = 15

            # Número de inimigos
            number_of_enemies = 5
            enemies = []

            # Adicionar inimigos
            for _ in range(number_of_enemies):
                enemy = turtle.Turtle()
                enemy.color("red")
                enemy.shape("circle")
                enemy.penup()
                enemy.speed(0)
                x = random.randint(-200, 200)
                y = random.randint(100, 250)
                enemy.setposition(x, y)
                enemies.append(enemy)

            enemy_speed = 2

            # Configurações do projétil
            bullet = turtle.Turtle()
            bullet.color("yellow")
            bullet.shape("triangle")
            bullet.penup()
            bullet.speed(0)
            bullet.setheading(90)
            bullet.shapesize(stretch_wid=0.5, stretch_len=0.5)
            bullet.hideturtle()
            bullet_speed = 20

            # Estado do projétil
            bullet_state = "ready"

            # Funções de movimento do jogador
            def move_left():
                x = player.xcor()
                x -= player_speed
                if x < -280:
                    x = -280
                player.setx(x)

            def move_right():
                x = player.xcor()
                x += player_speed
                if x > 280:
                    x = 280
                player.setx(x)

            def fire_bullet():
                nonlocal bullet_state
                if bullet_state == "ready":
                    bullet_state = "fire"
                    x = player.xcor()
                    y = player.ycor() + 10
                    bullet.setposition(x, y)
                    bullet.showturtle()

            def is_collision(t1, t2):
                distance = ((t1.xcor() - t2.xcor()) ** 2 + (t1.ycor() - t2.ycor()) ** 2) ** 0.5
                return distance < 15

            # Controles do teclado
            wn.listen()
            wn.onkeypress(move_left, "Left")
            wn.onkeypress(move_right, "Right")
            wn.onkeypress(fire_bullet, "space")

            # Loop principal do jogo
            while True:
                wn.update()

                for enemy in enemies:
                    x = enemy.xcor()
                    x += enemy_speed
                    enemy.setx(x)

                    if enemy.xcor() > 280 or enemy.xcor() < -280:
                        for e in enemies:
                            y = e.ycor()
                            y -= 40
                            e.sety(y)
                        enemy_speed *= -1

                    if is_collision(bullet, enemy):
                        bullet.hideturtle()
                        bullet_state = "ready"
                        bullet.setposition(0, -400)
                        x = random.randint(-200, 200)
                        y = random.randint(100, 250)
                        enemy.setposition(x, y)

                    if is_collision(player, enemy):
                        player.hideturtle()
                        enemy.hideturtle()
                        print("Game Over")
                        break

                if bullet_state == "fire":
                    y = bullet.ycor()
                    y += bullet_speed
                    bullet.sety(y)

                if bullet.ycor() > 275:
                    bullet.hideturtle()
                    bullet_state = "ready"
        except turtle.TurtleGraphicsError as e:
            print(f"Erro ao jogar Space Invaders: {e}")

    def open_minecraft_classic(self):
        """Abre o Minecraft Classic no navegador embutido."""
        self.do_navegador("https://classic.minecraft.net/")

    def open_music_notation(self):
        """Abre o Notador Musical."""
        notation_app = tk.Tk()
        notation_app.title("NTech Music Notation")
        notation_app.geometry("800x600")

        canvas = tk.Canvas(notation_app, bg='white')
        canvas.pack(fill=tk.BOTH, expand=True)

        def draw_note(x, y):
            """Desenha uma nota musical no canvas."""
            r = 10
            canvas.create_oval(x-r, y-r, x+r, y+r, fill='black')
            canvas.create_line(x, y-r, x, y+r, fill='black')

        def on_canvas_click(event):
            """Desenha uma nota quando o canvas é clicado."""
            draw_note(event.x, event.y)

        canvas.bind("<Button-1>", on_canvas_click)

        def clear_canvas():
            """Limpa o canvas."""
            canvas.delete('all')

        def save_image():
            """Salva o conteúdo do canvas como imagem."""
            try:
                file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
                if file_path:
                    canvas.postscript(file=file_path.replace('.png', '.eps'))
                    import PIL.Image
                    img = PIL.Image.open(file_path.replace('.png', '.eps'))
                    img.save(file_path)
                    os.remove(file_path.replace('.png', '.eps'))
                    messagebox.showinfo("Salvar Imagem", "Imagem salva com sucesso!")
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao salvar a imagem: {e}")

        button_frame = tk.Frame(notation_app)
        button_frame.pack(side=tk.BOTTOM, fill=tk.X)

        clear_button = tk.Button(button_frame, text="Limpar", command=clear_canvas)
        clear_button.pack(side=tk.LEFT)

        save_button = tk.Button(button_frame, text="Salvar", command=save_image)
        save_button.pack(side=tk.RIGHT)

        notation_app.mainloop()

    def change_password(self):
        new_password = simpledialog.askstring("Mudar Senha", "Digite a nova senha:", show='*')
        confirm_password = simpledialog.askstring("Confirmar Senha", "Confirme a nova senha:", show='*')
        if new_password == confirm_password:
            self.password = new_password
            messagebox.showinfo("Senha Alterada", "Senha alterada com sucesso!")
        else:
            messagebox.showerror("Erro", "As senhas não coincidem.")

if __name__ == '__main__':
    NTechConsole().cmdloop()
