import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, simpledialog
import subprocess
import platform
import webview
import os
import sys

class NTechConsoleApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()  # Esconde a janela principal
        self.show_loading_screen()
        self.password = "changeme"
        self.verify_password()
        self.root.deiconify()  # Mostra a janela principal após o carregamento
        self.create_main_window()
        self.root.mainloop()

    def show_loading_screen(self):
        loading_window = tk.Toplevel(self.root)
        loading_window.title("Carregando - NTechOS")
        loading_window.geometry("400x200")
        loading_window.configure(bg='white')

        word_art = """\
 _   _ _____         _        ___  ____
| \ | |_   _|__  ___| |__    / _ \/ ___|
|  \| | | |/ _ \/ __| '_ \  | | | \___ \
| |\  | | |  __/ (__| | | | | |_| |___) |
|_| \_| |_|\___|\___|_| |_|  \___/|____/


"""
        spinner = ['|', '/', '-', '\\']

        # Tela de carregamento
        loading_label = tk.Label(loading_window, text=word_art, font=("Courier", 10), bg='white', justify='left')
        loading_label.pack(pady=20)

        spinner_label = tk.Label(loading_window, text="Carregando...", font=("Courier", 12), bg='white')
        spinner_label.pack(pady=20)

        def spin():
            for cursor in spinner:
                spinner_label.config(text=f"Carregando {cursor}")
                loading_window.update_idletasks()
                loading_window.after(100)
        for _ in range(20):  # Número de iterações da animação
            spin()

        loading_window.destroy()

    def verify_password(self):
        entered_password = simpledialog.askstring("Senha", "Digite a senha:", show='*')
        if entered_password != self.password:
            print("Senha incorreta. Fechando o console.")
            sys.exit()

    def create_main_window(self):
        self.root.title("NTechOS Console")
        self.root.geometry("800x600")

        menu = tk.Menu(self.root)
        self.root.config(menu=menu)

        file_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="Arquivo", menu=file_menu)
        file_menu.add_command(label="Abrir Explorador de Arquivos", command=self.open_file_explorer)
        file_menu.add_command(label="Abrir NTech Text Editor", command=self.open_text_editor)
        file_menu.add_command(label="Abrir Calculadora", command=self.open_calculator)
        file_menu.add_command(label="Abrir Navegador", command=self.open_browser)
        file_menu.add_command(label="Sair", command=self.root.quit)

        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD)
        self.text_area.pack(expand=True, fill='both')

    def open_file_explorer(self):
        path = filedialog.askdirectory()
        if path:
            os.startfile(path)  # Para Windows
            # subprocess.run(['xdg-open', path])  # Para Linux

    def open_text_editor(self):
        text_editor = tk.Toplevel(self.root)
        text_editor.title("NTech Text Editor")
        text_editor.geometry("800x600")

        text_area = scrolledtext.ScrolledText(text_editor, wrap=tk.WORD)
        text_area.pack(expand=True, fill='both')

        font_choice = tk.StringVar(value="Courier")
        font_size = tk.IntVar(value=12)

        font_menu = tk.OptionMenu(text_editor, font_choice, *tk.font.families())
        font_menu.pack(side=tk.LEFT, padx=5)
        size_menu = tk.Spinbox(text_editor, from_=8, to=72, textvariable=font_size)
        size_menu.pack(side=tk.LEFT, padx=5)

        def update_font(*args):
            new_font = (font_choice.get(), font_size.get())
            text_area.config(font=new_font)

        font_choice.trace('w', update_font)
        font_size.trace('w', update_font)

        def save_file():
            file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if file_path:
                with open(file_path, 'w') as file:
                    file.write(text_area.get(1.0, tk.END))
                messagebox.showinfo("Salvar Arquivo", "Arquivo salvo com sucesso!")

        save_button = tk.Button(text_editor, text="Salvar", command=save_file)
        save_button.pack(side=tk.RIGHT, padx=5)

    def open_calculator(self):
        calc = tk.Toplevel(self.root)
        calc.title("Calculadora - NTechOS")
        calc.geometry("300x400")

        def evaluate(event=None):
            try:
                result = str(eval(display.get()))
                display.delete(0, tk.END)
                display.insert(tk.END, result)
            except Exception as e:
                display.delete(0, tk.END)
                display.insert(tk.END, "Erro")

        display = tk.Entry(calc, font=("Arial", 20), bd=10, insertwidth=4, width=14, borderwidth=4)
        display.grid(row=0, column=0, columnspan=4)

        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+'
        ]

        row = 1
        col = 0
        for button in buttons:
            if button == '=':
                btn = tk.Button(calc, text=button, padx=20, pady=20, bd=8, fg='black', font=("Arial", 18), command=evaluate)
                btn.grid(row=row, column=col, columnspan=2)
                col += 1
            else:
                btn = tk.Button(calc, text=button, padx=20, pady=20, bd=8, fg='black', font=("Arial", 18), command=lambda b=button: display.insert(tk.END, b))
                btn.grid(row=row, column=col)
            col += 1
            if col > 3:
                col = 0
                row += 1

    def open_browser(self):
        url = simpledialog.askstring("Navegador", "Digite o URL:", initialvalue='http://')
        if not url.startswith('http'):
            url = 'http://' + url
        try:
            webview.create_window('Navegador NTech', url)
            webview.start()
        except Exception as e:
            print(f"Erro ao abrir o navegador: {e}")

if __name__ == '__main__':
    NTechConsoleApp()
