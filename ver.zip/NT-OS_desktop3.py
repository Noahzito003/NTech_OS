import tkinter as tk
from tkinter import scrolledtext, filedialog, simpledialog, colorchooser, messagebox
import webview
import os
import datetime
import subprocess
import platform
import random
from PIL import Image, ImageTk, ImageDraw, ImageFont

class NTechOS:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("NTechOS")
        self.root.geometry("800x600")
        self.root.configure(bg='lightgray')

        # Adicionar plano de fundo
        self.bg_image = Image.open("background.jpg")  # Substitua por seu caminho de imagem
        self.bg_image = self.bg_image.resize((800, 600), Image.ANTIALIAS)
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.bg_label = tk.Label(self.root, image=self.bg_photo)
        self.bg_label.place(relwidth=1, relheight=1)

        # Barra de tarefas
        self.taskbar = tk.Frame(self.root, bg='darkgray', height=30)
        self.taskbar.pack(side=tk.BOTTOM, fill=tk.X)

        # Botões da barra de tarefas
        self.create_taskbar_button("Texto", self.open_text_editor)
        self.create_taskbar_button("Notação", self.open_music_notation)
        self.create_taskbar_button("Arquivos", self.open_file_explorer)
        self.create_taskbar_button("Navegador", self.open_browser)
        self.create_taskbar_button("Calculadora", self.open_calculator)
        self.create_taskbar_button("Pong", self.play_pong)
        self.create_taskbar_button("Space Invaders", self.play_space_invaders)
        self.create_taskbar_button("Minecraft", self.open_minecraft_classic)
        self.create_taskbar_button("Relógio", self.open_clock)
        self.create_taskbar_button("Executar", self.open_run_app)

        # Mensagem de boas-vindas
        self.display_welcome_message()

    def create_taskbar_button(self, text, command):
        button = tk.Button(self.taskbar, text=text, command=command)
        button.pack(side=tk.LEFT, padx=5, pady=5)

    def display_welcome_message(self):
        welcome_messages = [
            "Bem-vindo ao NTechOS! Explore o sistema usando a barra de tarefas.",
            "Olá! Acesse os aplicativos através da barra de tarefas.",
            "Saudações! Use a barra de tarefas para abrir os aplicativos do NTechOS.",
            "Bem-vindo de volta! Utilize a barra de tarefas para acessar os aplicativos."
        ]
        message = random.choice(welcome_messages)
        label = tk.Label(self.root, text=message, bg='lightgray', font=("Arial", 14))
        label.pack(pady=10)

    def open_text_editor(self):
        editor = tk.Toplevel(self.root)
        editor.title("NTech Text Editor")

        frame = tk.Frame(editor)
        frame.pack(padx=10, pady=10)

        font_label = tk.Label(frame, text="Fonte:")
        font_label.grid(row=0, column=0, padx=5, pady=5)
        self.font_var = tk.StringVar(value="Arial")
        font_menu = tk.OptionMenu(frame, self.font_var, *tk.font.families(), command=self.change_font)
        font_menu.grid(row=0, column=1, padx=5, pady=5)

        size_label = tk.Label(frame, text="Tamanho:")
        size_label.grid(row=0, column=2, padx=5, pady=5)
        self.size_var = tk.StringVar(value="12")
        size_menu = tk.OptionMenu(frame, self.size_var, *[str(size) for size in range(8, 73, 2)], command=self.change_font)
        size_menu.grid(row=0, column=3, padx=5, pady=5)

        color_button = tk.Button(frame, text="Cor do Texto", command=self.change_color)
        color_button.grid(row=0, column=4, padx=5, pady=5)

        self.text_area = scrolledtext.ScrolledText(editor, wrap=tk.WORD, width=80, height=20)
        self.text_area.pack(expand=True, fill='both', padx=10, pady=10)

        button_frame = tk.Frame(editor)
        button_frame.pack(pady=5)

        save_button = tk.Button(button_frame, text="Salvar", command=self.save_file)
        save_button.pack(side=tk.LEFT, padx=5)

        wordart_button = tk.Button(button_frame, text="Inserir WordArt", command=self.insert_wordart)
        wordart_button.pack(side=tk.LEFT, padx=5)

    def change_font(self, event=None):
        font_name = self.font_var.get()
        font_size = self.size_var.get()
        font_color = getattr(self, 'color_var', 'black')
        self.text_area.config(font=(font_name, font_size), fg=font_color)

    def change_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.color_var = color
            self.change_font()

    def insert_wordart(self):
        wordart_text = simpledialog.askstring("WordArt", "Digite o texto do WordArt:")
        if wordart_text:
            image = Image.new('RGB', (300, 100), color='white')
            draw = ImageDraw.Draw(image)
            try:
                wordart_font = ImageFont.truetype("arial.ttf", 50)
            except IOError:
                wordart_font = ImageFont.load_default()
            draw.text((10, 25), wordart_text, font=wordart_font, fill='black')
            image.save('wordart.png')
            wordart_image = Image.open('wordart.png')
            wordart_photo = ImageTk.PhotoImage(wordart_image)
            self.text_area.image_create(tk.END, image=wordart_photo)
            os.remove('wordart.png')

    def save_file(self):
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if file_path:
                with open(file_path, 'w') as file:
                    file.write(self.text_area.get(1.0, tk.END))
                messagebox.showinfo("Salvar Arquivo", "Arquivo salvo com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar o arquivo: {e}")

    def open_music_notation(self):
        notation = tk.Toplevel(self.root)
        notation.title("NTech Music Notation")

        canvas = tk.Canvas(notation, bg='white')
        canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas = canvas

        clear_button = tk.Button(notation, text="Limpar", command=self.clear_canvas)
        clear_button.pack(side=tk.LEFT, padx=5, pady=5)

        save_button = tk.Button(notation, text="Salvar Imagem", command=self.save_image)
        save_button.pack(side=tk.LEFT, padx=5, pady=5)

        canvas.bind("<Button-1>", self.on_canvas_click)

    def draw_note(self, x, y, pitch='C4'):
        r = 10
        self.canvas.create_oval(x-r, y-r, x+r, y+r, fill='black')
        self.canvas.create_line(x, y-r, x, y+r, fill='black')
        self.canvas.create_text(x, y + 15, text=pitch, fill='black')

    def on_canvas_click(self, event):
        pitch = simpledialog.askstring("Nota", "Digite o nome da nota (e.g., C4, D#5):")
        if pitch:
            self.draw_note(event.x, event.y, pitch)

    def clear_canvas(self):
        self.canvas.delete('all')

    def save_image(self):
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
            if file_path:
                self.canvas.postscript(file=file_path.replace('.png', '.eps'))
                img = Image.open(file_path.replace('.png', '.eps'))
                img.save(file_path)
                os.remove(file_path.replace('.png', '.eps'))
                messagebox.showinfo("Salvar Imagem", "Imagem salva com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar a imagem: {e}")

    def open_file_explorer(self):
        explorer = tk.Toplevel(self.root)
        explorer.title("Explorador de Arquivos")
        explorer.geometry("600x400")

        tree = tk.Treeview(explorer)
        tree.pack(fill=tk.BOTH, expand=True)

        def populate_tree(directory, parent=""):
            for item in os.listdir(directory):
                path = os.path.join(directory, item)
                if os.path.isdir(path):
                    node = tree.insert(parent, "end", text=item, open=False)
                    populate_tree(path, node)
                else:
                    tree.insert(parent, "end", text=item)

        populate_tree(os.getcwd())

    def open_browser(self):
        webview.create_window("NTechOS Browser", "https://www.example.com")
        webview.start()

    def open_calculator(self):
        if platform.system() == "Windows":
            subprocess.run("calc.exe")
        elif platform.system() == "Linux":
            subprocess.run(["gnome-calculator"])
        else:
            messagebox.showerror("Erro", "Calculadora não suportada neste sistema.")

    def play_pong(self):
        import turtle

        def pong_game():
            wn = turtle.Screen()
            wn.title("Pong")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            paddle_a = turtle.Turtle()
            paddle_a.speed(0)
            paddle_a.shape("square")
            paddle_a.color("white")
            paddle_a.shapesize(stretch_wid=6, stretch_len=1)
            paddle_a.penup()
            paddle_a.goto(-350, 0)

            paddle_b = turtle.Turtle()
            paddle_b.speed(0)
            paddle_b.shape("square")
            paddle_b.color("white")
            paddle_b.shapesize(stretch_wid=6, stretch_len=1)
            paddle_b.penup()
            paddle_b.goto(350, 0)

            ball = turtle.Turtle()
            ball.speed(1)
            ball.shape("square")
            ball.color("white")
            ball.penup()
            ball.goto(0, 0)
            ball.dx = 0.175
            ball.dy = -0.175

            def paddle_a_up():
                y = paddle_a.ycor()
                if y < 250:
                    y += 20
                    paddle_a.sety(y)

            def paddle_a_down():
                y = paddle_a.ycor()
                if y > -240:
                    y -= 20
                    paddle_a.sety(y)

            def paddle_b_up():
                y = paddle_b.ycor()
                if y < 250:
                    y += 20
                    paddle_b.sety(y)

            def paddle_b_down():
                y = paddle_b.ycor()
                if y > -240:
                    y -= 20
                    paddle_b.sety(y)

            wn.listen()
            wn.onkeypress(paddle_a_up, "w")
            wn.onkeypress(paddle_a_down, "s")
            wn.onkeypress(paddle_b_up, "Up")
            wn.onkeypress(paddle_b_down, "Down")

            while True:
                wn.update()

                ball.setx(ball.xcor() + ball.dx)
                ball.sety(ball.ycor() + ball.dy)

                if ball.ycor() > 290:
                    ball.sety(290)
                    ball.dy *= -1

                if ball.ycor() < -290:
                    ball.sety(-290)
                    ball.dy *= -1

                if ball.xcor() > 390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if ball.xcor() < -390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if (ball.dx > 0) and (350 > ball.xcor() > 340) and (paddle_b.ycor() + 50 > ball.ycor() > paddle_b.ycor() - 50):
                    ball.setx(340)
                    ball.dx *= -1

                if (ball.dx < 0) and (-350 < ball.xcor() < -340) and (paddle_a.ycor() + 50 > ball.ycor() > paddle_a.ycor() - 50):
                    ball.setx(-340)
                    ball.dx *= -1

        pong_game()

    def play_space_invaders(self):
        import turtle
        import random

        def space_invaders_game():
            wn = turtle.Screen()
            wn.title("Space Invaders")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            player = turtle.Turtle()
            player.speed(0)
            player.shape("square")
            player.color("white")
            player.penup()
            player.goto(0, -250)
            player.shapesize(stretch_wid=1, stretch_len=5)

            bullet = turtle.Turtle()
            bullet.speed(0)
            bullet.shape("square")
            bullet.color("red")
            bullet.penup()
            bullet.hideturtle()
            bullet.speed(40)

            invaders = []
            for _ in range(5):
                invader = turtle.Turtle()
                invader.speed(0)
                invader.shape("square")
                invader.color("green")
                invader.penup()
                invader.goto(random.randint(-300, 300), random.randint(100, 250))
                invaders.append(invader)

            def move_left():
                x = player.xcor()
                if x > -350:
                    x -= 20
                    player.setx(x)

            def move_right():
                x = player.xcor()
                if x < 350:
                    x += 20
                    player.setx(x)

            def shoot():
                if not bullet.isvisible():
                    bullet.setx(player.xcor())
                    bullet.sety(player.ycor() + 10)
                    bullet.showturtle()

            wn.listen()
            wn.onkeypress(move_left, "Left")
            wn.onkeypress(move_right, "Right")
            wn.onkeypress(shoot, "space")

            while True:
                wn.update()

                if bullet.isvisible():
                    bullet.sety(bullet.ycor() + 20)
                    if bullet.ycor() > 290:
                        bullet.hideturtle()

                for invader in invaders:
                    if bullet.distance(invader) < 20:
                        invader.goto(random.randint(-300, 300), random.randint(100, 250))
                        bullet.hideturtle()

        space_invaders_game()

    def open_minecraft_classic(self):
        webview.create_window("Minecraft Classic", "https://classic.minecraft.net/")
        webview.start()

    def open_clock(self):
        clock_window = tk.Toplevel(self.root)
        clock_window.title("Relógio - NTechOS")

        def update_time():
            now = datetime.datetime.now()
            time_str = now.strftime("%H:%M:%S")
            date_str = now.strftime("%d/%m/%Y")
            time_label.config(text=time_str)
            date_label.config(text=date_str)
            clock_window.after(1000, update_time)

        time_label = tk.Label(clock_window, font=("Arial", 48), bg="black", fg="white")
        time_label.pack()

        date_label = tk.Label(clock_window, font=("Arial", 24), bg="black", fg="white")
        date_label.pack()

        update_time()

    def open_run_app(self):
        app_name = simpledialog.askstring("Executar Aplicativo", "Digite o nome do aplicativo (ex: calc.exe):")
        if app_name:
            try:
                if platform.system() == "Windows":
                    subprocess.run(app_name)
                elif platform.system() == "Linux":
                    subprocess.run([app_name])
                else:
                    messagebox.showerror("Erro", "Aplicativo não suportado neste sistema.")
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao executar o aplicativo: {e}")

    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = NTechOS()
    app.run()
