import cmd
import platform
import subprocess
import webview
import os
import turtle
import datetime
import time
import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, simpledialog, colorchooser
from tkinter import ttk
from PIL import Image, ImageDraw, ImageFont
import random

class NTechConsole(cmd.Cmd):
    prompt = 'NTechOS Console> '
    intro = "Bem-vindo ao NTechOS Console. Digite 'help' para ver os comandos disponíveis."

    def __init__(self):
        super().__init__()
        self.system = platform.system()
        self.current_directory = os.getcwd()
        self.show_loading_screen()
        self.start_console()

    def show_loading_screen(self):
        """Cria e exibe a tela de carregamento com uma barra de progresso animada"""
        self.loading_root = tk.Tk()
        self.loading_root.title("Carregando NTechOS Console")
        self.loading_root.geometry("500x300")
        self.loading_root.configure(bg='black')

        tk.Label(self.loading_root, text="Carregando NTechOS Console...", font=("Arial", 16), fg='white', bg='black').pack(pady=20)

        self.progress = ttk.Progressbar(self.loading_root, length=400, mode='indeterminate')
        self.progress.pack(pady=20)
        self.progress.start()

        self.loading_root.after(3000, self.loading_root.destroy)

    def start_console(self):
        """Inicia o console após a tela de carregamento"""
        self.display_welcome_message()
        self.cmdloop()

    def display_welcome_message(self):
        """Exibe uma mensagem de boas-vindas aleatória ao iniciar o sistema"""
        welcome_messages = [
            "Bem-vindo ao NTechOS Console! Prepare-se para uma nova experiência.",
            "Olá! O NTechOS Console está pronto para uso.",
            "Saudações! O NTechOS Console foi iniciado com sucesso.",
            "Bem-vindo de volta! Explore o NTechOS Console e divirta-se."
        ]
        messagebox.showinfo("Bem-vindo ao NTechOS Console", random.choice(welcome_messages))

    def do_start(self, line):
        """Inicia o NTechOS Console"""
        print("Console iniciado.")

    def do_open(self, line):
        """Abre um aplicativo"""
        if line == 'texteditor':
            self.open_text_editor()
        elif line == 'musicnotation':
            self.open_music_notation()
        elif line == 'fileexplorer':
            self.open_file_explorer()
        elif line == 'browser':
            self.open_browser()
        elif line == 'calculator':
            self.open_calculator()
        elif line == 'pong':
            self.play_pong()
        elif line == 'spaceinvaders':
            self.play_space_invaders()
        elif line == 'minecraft':
            self.open_minecraft_classic()
        elif line == 'clock':
            self.open_clock()
        elif line == 'clear':
            os.system('cls' if platform.system() == 'Windows' else 'clear')
        else:
            print(f"Aplicativo {line} não reconhecido.")

    def open_text_editor(self):
        """Abre o NTech Text Editor"""
        root = tk.Tk()
        root.title("NTech Text Editor")

        # Interface Gráfica do Editor de Texto
        frame = tk.Frame(root)
        frame.pack(padx=10, pady=10)

        font_label = tk.Label(frame, text="Fonte:")
        font_label.grid(row=0, column=0, padx=5, pady=5)
        self.font_var = tk.StringVar(value="Arial")
        font_menu = tk.OptionMenu(frame, self.font_var, *tk.font.families(), command=self.change_font)
        font_menu.grid(row=0, column=1, padx=5, pady=5)

        size_label = tk.Label(frame, text="Tamanho:")
        size_label.grid(row=0, column=2, padx=5, pady=5)
        self.size_var = tk.StringVar(value="12")
        size_menu = tk.OptionMenu(frame, self.size_var, *[str(size) for size in range(8, 73, 2)], command=self.change_font)
        size_menu.grid(row=0, column=3, padx=5, pady=5)

        color_button = tk.Button(frame, text="Cor do Texto", command=self.change_color)
        color_button.grid(row=0, column=4, padx=5, pady=5)

        self.text_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=80, height=20)
        self.text_area.pack(expand=True, fill='both', padx=10, pady=10)

        button_frame = tk.Frame(root)
        button_frame.pack(pady=5)

        save_button = tk.Button(button_frame, text="Salvar", command=self.save_file)
        save_button.pack(side=tk.LEFT, padx=5)

        wordart_button = tk.Button(button_frame, text="Inserir WordArt", command=self.insert_wordart)
        wordart_button.pack(side=tk.LEFT, padx=5)

        root.mainloop()

    def change_font(self, event=None):
        """Muda a fonte do editor de texto"""
        font_name = self.font_var.get()
        font_size = self.size_var.get()
        font_color = self.color_var.get()
        self.text_area.config(font=(font_name, font_size), fg=font_color)

    def change_color(self):
        """Altera a cor do texto"""
        color = colorchooser.askcolor()[1]
        if color:
            self.color_var.set(color)
            self.change_font()

    def insert_wordart(self):
        """Insere WordArt no editor de texto"""
        wordart_text = simpledialog.askstring("WordArt", "Digite o texto do WordArt:")
        if wordart_text:
            # Cria uma imagem para o WordArt
            image = Image.new('RGB', (300, 100), color='white')
            draw = ImageDraw.Draw(image)
            try:
                wordart_font = ImageFont.truetype("arial.ttf", 50)
            except IOError:
                wordart_font = ImageFont.load_default()
            draw.text((10, 25), wordart_text, font=wordart_font, fill='black')
            image.save('wordart.png')
            wordart_image = tk.PhotoImage(file='wordart.png')
            self.text_area.image_create(tk.END, image=wordart_image)

    def save_file(self):
        """Salva o arquivo do editor de texto"""
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
            if file_path:
                with open(file_path, 'w') as file:
                    file.write(self.text_area.get(1.0, tk.END))
                messagebox.showinfo("Salvar Arquivo", "Arquivo salvo com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar o arquivo: {e}")

    def open_music_notation(self):
        """Abre o Notador Musical"""
        root = tk.Tk()
        root.title("NTech Music Notation")

        canvas = tk.Canvas(root, bg='white')
        canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas = canvas

        clear_button = tk.Button(root, text="Limpar", command=self.clear_canvas)
        clear_button.pack(side=tk.LEFT, padx=5, pady=5)

        save_button = tk.Button(root, text="Salvar Imagem", command=self.save_image)
        save_button.pack(side=tk.LEFT, padx=5, pady=5)

        canvas.bind("<Button-1>", self.on_canvas_click)

        root.mainloop()

    def draw_note(self, x, y, pitch='C4'):
        """Desenha uma nota musical no canvas"""
        r = 10
        self.canvas.create_oval(x-r, y-r, x+r, y+r, fill='black')
        self.canvas.create_line(x, y-r, x, y+r, fill='black')
        self.canvas.create_text(x, y + 15, text=pitch, fill='black')

    def on_canvas_click(self, event):
        """Desenha uma nota quando o canvas é clicado"""
        pitch = simpledialog.askstring("Nota", "Digite o nome da nota (e.g., C4, D#5):")
        if pitch:
            self.draw_note(event.x, event.y, pitch)

    def clear_canvas(self):
        """Limpa o canvas"""
        self.canvas.delete('all')

    def save_image(self):
        """Salva o conteúdo do canvas como imagem"""
        try:
            file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
            if file_path:
                self.canvas.postscript(file=file_path.replace('.png', '.eps'))
                img = Image.open(file_path.replace('.png', '.eps'))
                img.save(file_path)
                os.remove(file_path.replace('.png', '.eps'))
                messagebox.showinfo("Salvar Imagem", "Imagem salva com sucesso!")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao salvar a imagem: {e}")

    def open_file_explorer(self):
        """Abre o Explorador de Arquivos"""
        root = tk.Tk()
        root.title("Explorador de Arquivos")
        root.geometry("600x400")

        tree = ttk.Treeview(root)
        tree.pack(fill=tk.BOTH, expand=True)

        def populate_tree(directory, parent=""):
            """Preenche a árvore de diretórios"""
            for item in os.listdir(directory):
                path = os.path.join(directory, item)
                if os.path.isdir(path):
                    node = tree.insert(parent, "end", text=item, open=False)
                    populate_tree(path, node)
                else:
                    tree.insert(parent, "end", text=item)

        populate_tree(self.current_directory)

        root.mainloop()

    def open_browser(self):
        """Abre o navegador padrão"""
        webview.create_window("NTechOS Browser", "https://www.example.com")
        webview.start()

    def open_calculator(self):
        """Abre a calculadora padrão"""
        if self.system == 'Windows':
            subprocess.run(['calc'])
        elif self.system == 'Linux':
            subprocess.run(['gnome-calculator'])
        else:
            print("Calculadora não suportada para este sistema.")

    def play_pong(self):
        """Joga Pong"""
        def pong_game():
            wn = turtle.Screen()
            wn.title("Pong")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            paddle_a = turtle.Turtle()
            paddle_a.speed(0)
            paddle_a.shape("square")
            paddle_a.color("white")
            paddle_a.shapesize(stretch_wid=6, stretch_len=1)
            paddle_a.penup()
            paddle_a.goto(-350, 0)

            paddle_b = turtle.Turtle()
            paddle_b.speed(0)
            paddle_b.shape("square")
            paddle_b.color("white")
            paddle_b.shapesize(stretch_wid=6, stretch_len=1)
            paddle_b.penup()
            paddle_b.goto(350, 0)

            ball = turtle.Turtle()
            ball.speed(1)
            ball.shape("square")
            ball.color("white")
            ball.penup()
            ball.goto(0, 0)
            ball.dx = 0.175
            ball.dy = -0.175

            def paddle_a_up():
                y = paddle_a.ycor()
                if y < 250:
                    y += 20
                    paddle_a.sety(y)

            def paddle_a_down():
                y = paddle_a.ycor()
                if y > -240:
                    y -= 20
                    paddle_a.sety(y)

            def paddle_b_up():
                y = paddle_b.ycor()
                if y < 250:
                    y += 20
                    paddle_b.sety(y)

            def paddle_b_down():
                y = paddle_b.ycor()
                if y > -240:
                    y -= 20
                    paddle_b.sety(y)

            wn.listen()
            wn.onkeypress(paddle_a_up, "w")
            wn.onkeypress(paddle_a_down, "s")
            wn.onkeypress(paddle_b_up, "Up")
            wn.onkeypress(paddle_b_down, "Down")

            while True:
                wn.update()

                ball.setx(ball.xcor() + ball.dx)
                ball.sety(ball.ycor() + ball.dy)

                if ball.ycor() > 290:
                    ball.sety(290)
                    ball.dy *= -1

                if ball.ycor() < -290:
                    ball.sety(-290)
                    ball.dy *= -1

                if ball.xcor() > 390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if ball.xcor() < -390:
                    ball.goto(0, 0)
                    ball.dx *= -1

                if (ball.dx > 0) and (350 > ball.xcor() > 340) and (paddle_b.ycor() + 50 > ball.ycor() > paddle_b.ycor() - 50):
                    ball.setx(340)
                    ball.dx *= -1

                if (ball.dx < 0) and (-350 < ball.xcor() < -340) and (paddle_a.ycor() + 50 > ball.ycor() > paddle_a.ycor() - 50):
                    ball.setx(-340)
                    ball.dx *= -1

        pong_game()

    def play_space_invaders(self):
        """Joga Space Invaders"""
        def space_invaders_game():
            wn = turtle.Screen()
            wn.title("Space Invaders")
            wn.bgcolor("black")
            wn.setup(width=800, height=600)
            wn.tracer(0)

            player = turtle.Turtle()
            player.speed(0)
            player.shape("square")
            player.color("white")
            player.penup()
            player.goto(0, -250)
            player.shapesize(stretch_wid=1, stretch_len=5)

            bullet = turtle.Turtle()
            bullet.speed(0)
            bullet.shape("square")
            bullet.color("red")
            bullet.penup()
            bullet.hideturtle()
            bullet.speed(40)

            invaders = []
            for _ in range(5):
                invader = turtle.Turtle()
                invader.speed(0)
                invader.shape("square")
                invader.color("green")
                invader.penup()
                invader.goto(random.randint(-300, 300), random.randint(100, 250))
                invaders.append(invader)

            def move_left():
                x = player.xcor()
                if x > -350:
                    x -= 20
                    player.setx(x)

            def move_right():
                x = player.xcor()
                if x < 350:
                    x += 20
                    player.setx(x)

            def shoot():
                if not bullet.isvisible():
                    bullet.setx(player.xcor())
                    bullet.sety(player.ycor() + 10)
                    bullet.showturtle()

            wn.listen()
            wn.onkeypress(move_left, "Left")
            wn.onkeypress(move_right, "Right")
            wn.onkeypress(shoot, "space")

            while True:
                wn.update()

                if bullet.isvisible():
                    bullet.sety(bullet.ycor() + 20)
                    if bullet.ycor() > 290:
                        bullet.hideturtle()

                for invader in invaders:
                    if bullet.distance(invader) < 20:
                        invader.goto(random.randint(-300, 300), random.randint(100, 250))
                        bullet.hideturtle()

        space_invaders_game()

    def open_minecraft_classic(self):
        """Abre o Minecraft Classic no navegador"""
        webview.create_window("Minecraft Classic", "https://classic.minecraft.net/")
        webview.start()

    def open_clock(self):
        """Abre um relógio funcional"""
        root = tk.Tk()
        root.title("Relógio - NTechOS")

        def update_time():
            now = datetime.datetime.now()
            time_str = now.strftime("%H:%M:%S")
            date_str = now.strftime("%d/%m/%Y")
            time_label.config(text=time_str)
            date_label.config(text=date_str)
            root.after(1000, update_time)

        time_label = tk.Label(root, font=("Arial", 48), bg="black", fg="white")
        time_label.pack()

        date_label = tk.Label(root, font=("Arial", 24), bg="black", fg="white")
        date_label.pack()

        update_time()
        root.mainloop()

    def do_quit(self, line):
        """Encerra o console"""
        print("Saindo do NTechOS Console.")
        return True

if __name__ == '__main__':
    NTechConsole()
